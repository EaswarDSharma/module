#pragma once

#include <sqltypes.h>
#include <sqlspi.h>
#include <sqlext.h>
#include <sql.h>

typedef unsigned char DBBIT;
