#include <Operation.h>

namespace mssql
{
	Operation::~Operation()
	{
		//fprintf(stderr, "destruct Operation\n");
	}
}